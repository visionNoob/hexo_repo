---
name: 提出建议（Feature request）
about: 提出你对主题的建议（Suggest an idea for this project）

---

**提出你对主题的建议（Suggest your idea）**

**提出你觉得可行的解决方案 [可选]（Describe the solution you'd like）**

**提出其他的你考虑到的点（Describe alternatives you've considered）**

**其他**
